# 📅 ตารางการจองบ้านพักรีสอร์ท PWA

เว็บแอปพลิเคชันแบบ Progressive Web App (PWA) สำหรับแสดงตารางการจองบ้านพักรีสอร์ท โดยดึงข้อมูลจาก Google Sheets

## ✨ ฟีเจอร์

- 📱 รองรับการติดตั้งเป็นแอปบน iOS และ Android
- 🔄 อัพเดทข้อมูลอัตโนมัติทุก 5 นาที
- 📊 แสดงตารางการจองแบบ Real-time
- 🏠 แสดงข้อมูลการจอง 15 บ้านพัก
- 💾 ทำงาน Offline ได้
- 🎨 UI สวยงาม รองรับ Dark Mode

## 🚀 วิธีการติดตั้ง

### 1. เตรียม Google Sheet

1. เปิด Google Sheet ของคุณ: https://docs.google.com/spreadsheets/d/1IshovQni9Eiq9IeRdDg_2cXTSSkC7YIK2fbDTm_dcs0/edit
2. คลิก **Share** (แชร์) ที่มุมขวาบน
3. เลือก **Anyone with the link** และตั้งเป็น **Viewer**
4. คัดลอก Link และบันทึกไว้

### 2. ตรวจสอบคอลัมน์ใน Sheet

Sheet ต้องมีคอลัมน์ต่อไปนี้:
- `Date_ck_in` - วันที่เช็คอิน
- `Date_ck_out` - วันที่เช็คเอาท์
- `Customer` - ชื่อลูกค้า
- `Phone_no` - เบอร์โทรศัพท์
- `Total_Price` - ราคาทั้งหมด
- `overdue` - ค้างชำระ
- `Other` - หมายเหตุ
- `SPLIT_HBK1` ถึง `SPLIT_HBK15` - ชื่อบ้านที่จอง

### 3. Deploy เว็บไซต์

#### วิธีที่ 1: ใช้ GitHub Pages

1. สร้าง Repository ใหม่บน GitHub
2. อัพโหลดไฟล์ทั้งหมด:
   - `index.html`
   - `app.js`
   - `manifest.json`
   - `service-worker.js`
   - `icon-192.png`
   - `icon-512.png`

3. ไปที่ Settings > Pages
4. เลือก Source เป็น `main` branch
5. คลิก Save
6. เว็บไซต์จะพร้อมใช้งานที่ `https://yourusername.github.io/repository-name`

#### วิธีที่ 2: ใช้ Netlify/Vercel

1. สมัครบัญชี Netlify หรือ Vercel
2. ลาก folder ทั้งหมดไปวาง
3. Deploy เสร็จทันที!

### 4. ติดตั้งแอปบนมือถือ

#### สำหรับ iOS (iPhone/iPad):

1. เปิด Safari
2. ไปที่เว็บไซต์ของคุณ
3. กด ไอคอน Share (ปุ่มแชร์)
4. เลื่อนลงแล้วเลือก **Add to Home Screen**
5. ตั้งชื่อแอป แล้วกด **Add**

#### สำหรับ Android:

1. เปิด Chrome
2. ไปที่เว็บไซต์ของคุณ
3. กดที่เมนู (⋮) มุมขวาบน
4. เลือก **Add to Home Screen**
5. ตั้งชื่อแอป แล้วกด **Add**

หรือจะมี popup แจ้งให้ติดตั้งอัตโนมัติ

## 📱 การใช้งาน

### หน้าจอหลัก

- **ตาราง**: แสดงการจองทั้งหมดในรูปแบบปฏิทิน
- **วันที่ปัจจุบัน**: แถวที่ไ highlight สีฟ้า
- **ข้อมูลการจอง**: แสดงเซลล์สีเหลือง พร้อมข้อมูล:
  - 👤 ชื่อลูกค้า
  - 📱 เบอร์โทร
  - 💰 ราคาทั้งหมด
  - ⚠️ ค้างชำระ (ถ้ามี)
  - 📝 หมายเหตุ (ถ้ามี)

### ปุ่มฟังก์ชัน

- **🔄 รีเฟรช**: อัพเดทข้อมูลจาก Google Sheet
- **อัพเดทอัตโนมัติ**: ทุก 5 นาที

## 🎨 บ้านพักทั้งหมด (15 บ้าน)

1. ซอมนา
2. ฮอมฮัก
3. อุ่นละมุน
4. เพียงตะวัน
5. ผาหมวกผาหนอง
6. ภูสอยดาว
7. ภูไก่ห้อย
8. ภูหัวฮ่อม
9. ภูสวนทราย
10. ภูเก้าง้อม
11. ศรีเพชร
12. อินทอง
13. ธารสวรรค์
14. นาHugหลาย
15. เคียงดาว

## 🔧 การแก้ไขปัญหา

### ไม่แสดงข้อมูล

1. ตรวจสอบว่า Google Sheet เป็น **Public** (Anyone with link can view)
2. ตรวจสอบว่าชื่อ Sheet เป็น **booking**
3. ตรวจสอบว่ามีคอลัมน์ครบถ้วน
4. เปิด Console ใน Browser (F12) เพื่อดู error

### ไม่สามารถติดตั้งแอปได้ (iOS)

1. ต้องใช้ **Safari** เท่านั้น (Chrome ไม่รองรับ)
2. เว็บไซต์ต้องเป็น **HTTPS**
3. ตรวจสอบว่ามีไฟล์ `manifest.json` ครบ

### ข้อมูลไม่อัพเดท

1. กดปุ่ม **🔄 รีเฟรช**
2. Clear Cache บน Browser
3. ลบแอปแล้วติดตั้งใหม่

## 📝 รูปแบบวันที่ที่รองรับ

- `DD/MM/YYYY` เช่น 25/12/2024
- `MM/DD/YYYY` เช่น 12/25/2024
- `YYYY-MM-DD` เช่น 2024-12-25

## 🛠️ เทคโนโลยีที่ใช้

- HTML5
- CSS3 (Gradient, Flexbox)
- Vanilla JavaScript
- PWA (Service Worker, Web Manifest)
- Google Sheets API (CSV Export)

## 📄 ไฟล์ในโปรเจค

```
.
├── index.html          # หน้าหลัก
├── app.js             # JavaScript logic
├── manifest.json      # PWA manifest
├── service-worker.js  # Service worker สำหรับ offline
├── icon-192.png       # ไอคอนแอป 192x192
├── icon-512.png       # ไอคอนแอป 512x512
└── README.md          # เอกสารนี้
```

## 🔐 ความปลอดภัย

- ไม่ต้องใช้ API Key (ใช้ CSV Export)
- ข้อมูลอ่านอย่างเดียว (Read-only)
- ไม่มีการเก็บข้อมูลส่วนตัว
- ทำงานบน Client-side ทั้งหมด

## 📞 ติดต่อ/สนับสนุน

หากมีปัญหาหรือต้องการความช่วยเหลือ:
- เปิด Issue บน GitHub
- ติดต่อผู้พัฒนา

## 📜 License

MIT License - ใช้งานได้ฟรี แก้ไขได้ตามต้องการ

---

**สร้างด้วย ❤️ โดย Claude AI**
